package lesson4.classwork;

import java.awt.*;

public class Circle implements Shape {
    private final Point centre;
    private final double radius;

    public Circle(Point centre, double radius) {
        this.centre = centre;
        this.radius = radius;
    }

    @Override
    public void draw(Graphics g) {
        g.drawOval(centre.getX(), centre.getY(), (int) radius, (int) radius);
    }
}
