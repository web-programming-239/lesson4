package lesson4.classwork;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class MyFrame extends JFrame {
    public MyFrame(String title) throws HeadlessException {
        super(title);
        setSize(1000, 1000);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);

        //         Было:
        List<Point> points = new ArrayList<>();
        for (int i = 0; i < 5; i++) {
            points.add(new Point((i + 1) * 50, (i + 1) * 50));
        }

        List<Circle> circles = List.of(
                new Circle(points.get(0), 30),
                new Circle(points.get(1), 50),
                new Circle(points.get(2), 70)
        );

        List<Rect> rects = new ArrayList<>();
        rects.add(new Rect(new Point(0, 0), 100, 50));
        rects.add(new Rect(new Point(0, 0), 50, 50));
//
//        points.forEach(s -> s.draw(g));
//        circles.forEach(s -> s.draw(g));
//        rects.forEach(s -> s.draw(g));

//         Стало:
        List<Shape> shapeList = new ArrayList<>();

        shapeList.addAll(rects);
        shapeList.addAll(circles);
        shapeList.addAll(points);

        shapeList.forEach(shape -> {
            shape.draw(g);
        });
    }
}
