package lesson4.classwork;

import java.awt.*;

public class Rect implements Shape{
    private final Point leftUpperPoint;
    private final int height;
    private final int width;
    public Rect(Point leftUpperPoint, int height, int width) {
        this.leftUpperPoint = leftUpperPoint;
        this.height = height;
        this.width = width;
    }

    @Override
    public void draw(Graphics g) {
        g.drawRect(100, 100 , 100, 100);
        g.fillRect(100, 100 , 100, 100);
    }
}
