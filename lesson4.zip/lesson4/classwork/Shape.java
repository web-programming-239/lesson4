package lesson4.classwork;

import java.awt.*;

public interface Shape {
    void draw(Graphics g);
}
