## lesson4

Сегодня мы с вами поговорим про язык Java, ООП, да и в целом напишем какие-нибудь вещи, которые смогут вам при создании
ваших личных проектов.

... далее следует устная теор. часть ...

## ДЗ

Мы с вами обусловились писать веб-сервис для бронирования кабинетов в школе. Сейчас все что у нас есть - фронт, то, что
видит пользователь. Сегодня я хочу чтобы мы с вами прикоснулись к "бэку" - тому, чего пользователь не видит, но из-за
чего все, собственно говоря, и работает.

Придумайте реализацию следующих сущностей:

- Teacher, два строковых поля "name", "surname" - имя и фамилия соответственно.

```java
String name; // Имя учителя

String surname; // Фамилия учителя
```

- Room, одно строковое поле "room" - номер кабинета.

```java
String room; // номер кабинета
```

- Reservation с полями:
```java
Teacher teacher; // соответственно учитель, бронирующий кабинет

Room room; // кабинет, который он хочет забронировать

String target; // цель бронирования

Date startTime; // время начало брони

Date endTime; // время конца брони
```
- Последним реализуйте ReservationService - сервис (Java класс), с единственным полем

```java
List<Reservation> reservations; // Список всех текущих резерваций
```

С методами:

```java
addReservation(Reservation reservation); // добавляет резервацию из параметров в reservations

showReservations(); // выводит каждую резервацию из reservations на экран
```

NOTE: Важно помнить, что при попытке добавить резервацию с уже "занятыми" временем и кабинетом - следует выдать
человеко-читаемое сообщение об ошибке. И оставлять бронь за первым учителем. 

NOTE: Кидать исключения на прямую не обязательно - достаточно вывести на экран что-то
осознанное.

## Система оценивания

Чтобы проверить качество и правильность выполнения вашей работы, следующий код:

```java
private static final ReservationService reservationService = new ReservationService();

public static void main(String[] args) throws ParseException {
        SimpleDateFormat formatter = new SimpleDateFormat("hh:mm", Locale.ENGLISH);
        formatter.setTimeZone(TimeZone.getTimeZone("Russia/Moscow"));

        Teacher t1 = new Teacher("Denis", "Ushakov");
        Teacher t2 = new Teacher("Fedor", "Lyanguzov");
        Teacher t3 = new Teacher("SUPER", "TEACHER");

        Room r1 = new Room("208");
        Room r2 = new Room("108");
        Room r3 = new Room("303");

        String target1 = "Информатика 10-5";
        String target2 = "Химия 11-3";
        String target3 = "Литература 8-1";


        Date timeStart1 = formatter.parse("10:30");
        Date timeEnd1 = formatter.parse("11:30");

        Date timeStart2 = formatter.parse("10:30");
        Date timeEnd2 = formatter.parse("11:30");

        Date timeStart3 = formatter.parse("13:30");
        Date timeEnd3 = formatter.parse("15:00");


        Reservation reservation1 = new Reservation(t1, r1, target1, timeStart1, timeEnd1);
        Reservation reservation2 = new Reservation(t2, r1, target2, timeStart2, timeEnd2);
        Reservation reservation3 = new Reservation(t3, r3, target3, timeStart3, timeEnd3);

        reservationService.addReservation(reservation1);
        reservationService.addReservation(reservation2);
        reservationService.addReservation(reservation3);

        reservationService.showReservations();
}
```

Должен успешно компилироваться и выводить на экран примерно следующее:

```java
Time from 13:30:00, to 14:30:00 at room 208 is already reserved by Denis Ushakov
        
Reservation:
    Room: 208
    Teacher: Denis Ushakov
    Time from: 13:30:00
    Time to: 14:30:00
        
Reservation:
    Room: 303
    Teacher: SUPER TEACHER
    Time from: 16:30:00
    Time to: 18:00:00
```